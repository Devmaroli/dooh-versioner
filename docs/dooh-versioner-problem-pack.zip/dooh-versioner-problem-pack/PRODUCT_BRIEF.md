# Product brief: DOOH Versioner (working name)

## 1. Vision
A **local, Bannerflow-style versioning and auto-resize tool for DOOH (digital out-of-home)**, built for M2R's real screen network in Kuwait and the GCC. You give it one or a few client masters plus a version sheet. It produces every booked screen size in **English and Arabic (RTL)**. The output stays editable and non-destructive, a senior designer would sign off on the layouts, and it is ready to render and QA.

## 2. Users
- **Primary: Kapildev, DOOH production designer at M2R.** Day to day he:
  1. checks client material against the booked screens (sizes, languages, missing elements);
  2. adapts artwork in After Effects (Screen Adapter tags, precomps);
  3. renders in Adobe Media Encoder (stills and MP4);
  4. runs QA on legibility, safe areas, contrast, Arabic and combined faces;
  5. replies to account managers (AMs) about what's missing or wrong.
- **Secondary:** AMs, who get QA notes and previews, and the design team, who get requests such as live text, an unhidden logo or a stacked tagline.

## 3. Problems it solves
- Resizing one campaign by hand to about 100 real screen sizes (ribbons up to ~14:1, towers up to ~1:5.5, multi-face walls) and to EN and AR is slow and error-prone.
- Quality varies: margins, logo clear space, text over the product, small copy on tall columns, Arabic handled as an afterthought.
- No quick pre-flight on client material (raster-only copy, hidden logo, EN/AR packs that differ, size mismatch).
- QA, reporting and AM replies are manual.

## 4. Scope
**DOOH only:** static and motion screens, combined and multi-face screens. Not social, web banners or print.

## 5. Inputs
- **Masters:** PSD/PSB, AI, SVG/PDF/EPS, flat images (PNG/JPG), and After Effects projects through Screen Adapter tags.
- **Tool family:** PhotoCraft, VectorCraft, EffectCraft, EncodeCraft (M2R tools: importers, templates, encode).
- **Version data:** CSV/Excel sheet with one row per version (language, headline, offer, price, legal, colour and so on).
- **Screens:** Screen Manager / Screen Adapter JSON configs (real sizes only, never invented) plus a paste-screens matcher for booking lists.

## 6. Outputs
- JPG and PNG stills, and MP4.
- Editable EffectCraft templates (layers kept, tags kept).
- EncodeCraft jobs for encoding plus QA.
- Audit reports (HTML/CSV) per tile and per campaign.

## 7. User rules (non-negotiable unless the artwork analysis overrides a default)
1. **Non-destructive stack.** Every change is a layer or parameter; the original is never altered.
2. **AI only for placement and decisions.** No AI-generated copy, logos or products.
3. **AI background fill is opt-in and the last resort**, after crop, extend with a flat colour, mirror and blur.
4. **Change badges:** every automatic change shows a badge with accept or revert. **Auto-apply threshold is 0.8 confidence**; below that it is a suggestion only.
5. **Text never overlaps the product.** The price is always clear.
6. **Safe margins ≥ 6% of the short side.** Keep logo clear space.
7. **Spacing unit U = 0.25 × headline height** (for example logo→headline ≥ 6U).
8. **Arabic:**
   - no tracking;
   - kashida only on single-line wide headlines, max 3 per word;
   - Arabic size 110–115% of EN;
   - mirrored order (RTL);
   - contrast floors 4.5:1 body and 3:1 large.
9. **Skills are defaults.** The artwork analysis (live vs raster text, palette, focal point, hidden layers) overrides them.
10. **Layout library per screen**, with zones per format class and tier.
11. **Real sizes only, from the Screen Manager JSON.** The paste-screens matcher maps booked names to presets.
12. **Multi-master:** auto-pick by aspect ratio (log distance, same family, coverage), with a per-screen override.
13. **Language from the filename suffix** (`_AR`, `-ar`, ` Ar`, `Arabic`, `عربي` → AR; `_EN` … → EN; none = EN). The EN master feeds EN and the AR master feeds AR.
14. **Flow:** two steps, **Load & tag → Adapt → Export**. EN/AR pairs toggle (pairs or separate tiles). Focus view (fit, 1:1, zoom, pan).
15. Combined screens: Piccadilly sync is 6080 by a 1 px crop (never scaled). Thuraya is two separate screens (2624×608 + 960×540). The Palms is 4 panels. Alshaheed shape groups are ASSUMED.

## 8. AI providers and roles
- **Local first:** rules engine, template composer, audit.
- **Cloud / assist:** Claude, Grok, GPT and Jev AI. They propose layout parameters in the `layout-params` JSON schema (Mode B), critique against the rubric (`ai/rubric.json`) and label roles. They never draw pixels, except the opt-in background fill.
- Thresholds: auto-apply ≥ 0.8; below that, show a suggestion. Provider choice per task is an open question.

## 9. Stack
TypeScript engine (`engine/adapt.ts`, esbuild → browser IIFE and Node CJS), single-page HTML prototype (canvas), ag-psd for PSD in the browser (psd-tools for local checks), Node unit tests, a headless-Chromium audit, and Vercel for the public prototype (code and sample art only). Electron is planned for local use.

## 10. Roadmap
**Done (prototype v1.5):**
- Screen presets from real JSON, plus combiners and multi-face screens.
- Per-class templates and the layout library.
- Audit with 20 criteria, HTML/CSV reports and an auto-scrim.
- Paste-screens matcher.
- Multi-master import with ratio auto-pick and override; language masters.
- EN/AR pair cards, grid toggle, focus view.
- PSD import with role labelling (live text and raster heuristics).
- Real layer pixel rendering, baked-tagline reflow at word gaps (RTL aware), layer effects (overlay, shadow, glow, stroke).
- Pixel-based contrast audit, hero repeat on equal faces, filename language detection.
- Step 1 Load & tag mockup.

**Next:**
1. Wire the two-step flow (Load & tag → Adapt → Export) with a needs-attention queue.
2. Live-text rebuild: re-typeset copy from the version sheet when masters lack live text, or OCR plus font match.
3. Export pipeline: stills through headless Chromium, MP4 through EffectCraft/EncodeCraft, editable templates.
4. Electron desktop app (local files, client art never leaves the machine).

## 11. Success metrics (proposed)
- ≥ 90% of tiles accepted without manual edits; time from booking to delivered set cut by ≥ 70%.
- 0 hard fails (text over product, outside the safe area, text below the legibility floor) in shipped tiles.
- Audit score agrees with designer judgement (rank correlation ≥ 0.7 on a labelled set).
- Arabic tiles pass RTL checks at the same rate as EN.

## 12. Current status (2026-10-29)
- **Default sample audit:** 200 tiles (100 sizes × EN/AR), average 98, 51% pass every criterion.
  - Top fails: Typography ×26 (offer widows), Contrast ×25, Spacing U ×20, Safe margins ×16, Format playbook ×16, Logo clear space ×12, Legibility ×11.
- **Real client test (Rio, raster-only masters):** 200 tiles, 0 overlaps, 0 outside, 0 headlines under 2%, median headline 6.2% of height, average 96.2.
  - Contrast fails on every tile because the master itself is white on salmon = 2.0:1.
- **Public prototype:** https://dooh-versioner-proto.vercel.app (code and sample art only).

## 13. Decisions
**Made:**
- Palms is 4 panels; Thuraya is 2 screens; Piccadilly is a 1 px crop.
- Contrast floors stay at 4.5:1 / 3:1.
- Alshaheed shape groups stay ASSUMED.
- Mode B outputs `layout-params`.
- Language masters; language from filename suffix.
- Client art stays local.

**Still open:** see PROBLEMS.md. Main ones:
- how far the auto-scrim may change client art;
- the minimum headline size for tall columns (viewing distance);
- live-text rebuild versus asking the design team;
- AI provider roles;
- how far the audit should be trusted.
