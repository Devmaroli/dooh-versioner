# Architecture (short)

## Stack
- **Engine:** TypeScript (`engine/adapt.ts`), with no runtime dependencies. esbuild builds `proto/adapt.js` (browser IIFE `Adapt`) and `engine/build/adapt.cjs` (Node tests).
- **UI:** a single-page prototype (`proto/index.html`, canvas 2D) plus `presets.js` (embedded Screen Manager JSON). ag-psd 34 runs in the browser for PSD.
- **Tests:** about 17 Node test files, plus a headless Chromium audit (`#auditall`) that writes the HTML/CSV reports.
- **Hosting:** Vercel static deploy of the code and sample art only. Electron is planned for local use.

## Pipeline
1. **Import:** PSD/SVG/image goes through `fromAgPsd` / `fromSvg` into an `Artwork` (layer tree, boxes, text, blend, opacity, pixels).
2. **Tag:**
   - `mapRoles`: tag grammar first, then name heuristics, then geometry. Raster text means aspect ≥4 strips; multiply means shadow.
   - `analyseArtwork`: palette, focal point, style, live/raster text, hidden logo, language, protected layers.
3. **Masters:**
   - `langFromFilename` / `detectMasterLang`;
   - `pickMaster` / `pickMasterForLang` (log-ratio distance, family, coverage) with a per-screen override.
4. **Screens:**
   - Screen Manager JSON goes through `importScreens` / `importCombiners` (faces, h-dup/v-dup, crops).
   - The paste matcher maps booking names to presets.
5. **Plan:**
   - classify the orientation class (xw, uw, w, sq, v, uv, xv) and tier;
   - pick a template or the layout library zones;
   - `compose` / `composeFaces`;
   - spacing rules (U = ¼ headline);
   - clear zones (text never over product);
   - Arabic rules.
6. **Render:**
   - Template mode: vector text and shapes.
   - Pixel mode: real layer pixels per role.
     - Same ratio: the master as-is.
     - Otherwise: flat background or focal-point crop; product in the product zone; copy as one unit, split, or stacked; the baked tagline re-flowed at word gaps; effects baked in.
7. **Audit:** `auditTile` / `auditCampaign` check 20 criteria (skill `dooh-design-audit`), with pass ≥ 80. Pixel mode measures contrast from the rendered pixels. An auto-fix scrim is optional.
8. **Export (planned):** PNG/JPG through headless Chromium; MP4 and editable templates through EffectCraft/EncodeCraft.

## Data model (main types)
- `ArtLayer`: id, name, kind, role, box, text, font, hidden, blend, opacity, lang, px, children
- `Artwork`: source, w, h, layers, topFirst
- `ScreenPreset`: name, w, h, group, kind (screen or combined), faces[]
- version row: version_id, lang, dir, headline, offer, price, legal, color
- `AuditTile` / `AuditRow`: criterion, score, pass, measured, reason, fix

## Tag grammar (layer names)
Format: `Name @role[.flag…]`
- Roles: headline, offer, product, logo, price, legal, bg.
- `.clear[N|Np]` keeps other elements clear by N px or N%.
- `.overlap` allows overlap.
- Screen Adapter tags in AE are mapped to the same roles.

## Rule layers (lowest to highest priority)
1. **Skill defaults:** spacing, margins, Arabic, format playbook.
2. **Layout library zones per screen.**
3. **Artwork analysis overrides:** style, palette, focal point, raster text, protected layers.
4. **Explicit layer tags.**
5. **User overrides (badges accept/revert).**

Hard constraints sit above all of these: no text over the product, inside the safe area, contrast floors, real sizes only.
