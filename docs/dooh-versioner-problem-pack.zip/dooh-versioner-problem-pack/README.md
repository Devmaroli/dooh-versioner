# DOOH Versioner: problem pack (2026-10-29)

Read in this order:
1. **PRODUCT_BRIEF.md**: what the product is, who it's for, the rules, status and roadmap.
2. **PROMPT.md**: paste this into the AI you're asking for solutions.
3. **PROBLEMS.md**: every open problem, with evidence.
4. **ARCHITECTURE.md**: stack, pipeline, data model, tag grammar, rule layers.
5. **RESOURCES.md**: verified repos, skills and tools by category (incl. Karpathy skills and reverse-engineering resources), mapped to P1–P18 with licence fit.

| Folder | Contents |
|---|---|
| spec/ | SPEC.md, the full product and engine spec (changelog in §10.x) |
| engine/ | adapt.ts (engine), layout-lib.ts, tests/*.test.js (Node; build with esbuild → build/adapt.cjs) |
| ai/ | design-rules.md, rubric.json, layout-params.schema.json, example.json |
| layouts/ | library.json (layout library per screen), validate.py |
| skills/ | dooh-* SKILL.md (current); _fixed-versions/ (reviewed/fixed drafts) |
| reports/ | audit-all-presets.csv/html (sample art, 200 tiles), layout-validation-report.md, advanced-design-report.md |
| shots/ | screenshots made with the default sample art (before/after, ribbons, PSD import, focus view, EN/AR pairs, grid) |
| shots/client-rio/ | **CONFIDENTIAL CLIENT ARTWORK** (Bolton Group, "Rio"): low-res JPGs of real-run best/worst tiles and the Load & tag mockup. Don't share or publish; use only to understand the problems. |
| screens/ | Screen Manager / Screen Adapter JSON configs (real M2R sizes and combiners) |

Excluded: client PSDs, secrets/tokens/.env/.vercel, node_modules, build output.
