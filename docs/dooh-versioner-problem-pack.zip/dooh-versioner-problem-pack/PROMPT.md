# Prompt (paste as is, and attach the zip)

You are a senior engineer and DOOH art director with deep experience in automated creative versioning (Bannerflow, Celtra, Adobe GenStudio), computational layout, typography (Latin and Arabic) and image processing.

**Read first:** PRODUCT_BRIEF.md, then PROBLEMS.md and ARCHITECTURE.md. RESOURCES.md lists candidate repos and tools we already found (verified, with licences). Use, rank or replace them, and flag licence risks. Use spec/, engine/, ai/, skills/, reports/, screens/ and shots/ as evidence. shots/client-rio/ is confidential client artwork; use it only to understand the problems.

## Context
- We're building a **local** DOOH versioning and auto-resize app, like Bannerflow, for M2R's real screens in Kuwait and the GCC.
- It handles about 100 real sizes from Screen Manager JSON: ribbons up to ~14:1, towers up to ~1:5.5, and multi-face or combined walls.
- Every version comes in **English and Arabic (RTL)**.
- Hard rules:
  - the stack is non-destructive and the output is editable (EffectCraft templates, layers kept);
  - **AI is used only for placement and decisions**, never to make copy, logos or products;
  - **AI background fill is opt-in and the last resort**;
  - text never overlaps the product;
  - margins ≥ 6% of the short side; spacing U = ¼ headline;
  - Arabic: no tracking; kashida ≤ 3 per word and only on single-line wide headlines; AR 110–115% of EN;
  - contrast floors 4.5:1 / 3:1;
  - real sizes only;
  - client art stays local.

## What we want from you
For **each problem in PROBLEMS.md** (keep our numbering):
1. **Ranked solutions:** best first, 2–4 options. For each, say why it ranks there.
2. **How:** concrete algorithms, data structures, pseudo-code or TS signatures, and named open-source libraries or models (with licence) that work **locally** (browser or Node or Electron; Python sidecar allowed).
3. **Tradeoffs:** quality, speed, effort (S/M/L), risk, licence, and whether it keeps output editable and non-destructive.
4. **Testing and measurement:** a metric, a test fixture, and pass thresholds; how to check the result against designer judgement.
5. **Questions for the design team or client** that would remove the problem at the source (for example "deliver live text", "stacked tagline variant").
6. Mark guesses **ASSUMED**. Don't invent screen sizes or client facts.

Then give:
- **Cross-cutting recommendations:** architecture changes, an audit redesign, and an AI provider strategy (local vs Claude/Grok/GPT/Jev: which does what, confidence thresholds, cost).
- **A phased plan:**
  - Phase 0: quick wins, ≤ 1 week.
  - Phase 1: 2–4 weeks.
  - Phase 2: later.
  - Each phase lists deliverables, dependencies and exit criteria.
- **Top 5 risks** and how to reduce each.

## Response format
- Markdown. For each problem: `## P<n>: <title>`, then a short diagnosis (1–3 lines), a solutions table (rank | approach | libs | effort | risk | editable?), then **Recommended**, **Test**, **Ask design team**.
- Then: Cross-cutting, Phased plan (a table), Risks, Open questions back to us.
- Be concise and specific. Prefer numbers, thresholds and code sketches over prose.
