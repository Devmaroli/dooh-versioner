# Open problems (2026-10-29, prototype v1.5)

The evidence comes from two runs:
- **Sample run:** default sample art, 200 tiles. See `reports/audit-all-presets.*`.
- **Rio run:** real client masters Rio_EN/AR, 1920×1080, raster-only copy, 200 tiles. See `shots/client-rio/`.

U = ¼ headline height. Tile names are M2R preset names.

---
## P1: Raster-only copy (no live text) limits tall columns
- **Symptom:** the client PSDs have no live text; the tagline is one rasterised line (EN 1528×67 px). On tall columns the copy can only be scaled, so it ends up tiny.
- **Evidence (Rio run):**
  - Al Nassar Tower Vertical (960×5328) and 1st Ring Road (1008×5184): EN headline is **2.0%** of screen height against a **2.5% target** (ASSUMED from viewing distance). AR is 3.3%.
  - Before the fixes, 37/200 tiles had a headline under 2%; now 0.
  - Screenshot: `shots/client-rio/real-worst.jpg`.
- **Tried:** splitting the raster at word gaps (empty alpha columns ≥ 22% of line height) and re-flowing into up to 6 lines (RTL keeps order); giving the headline up to 55% of the copy zone. The limit is the longest word against the column width.
- **Constraints:** we can't generate or alter copy with AI; the output must stay editable; we can't invent fonts.
- **Open:**
  1. OCR plus font matching to rebuild live text (EN and Arabic)? Which libraries work locally?
  2. Re-typeset from the version sheet using brand fonts?
  3. Which viewing-distance formula to use for the minimum size (px pitch, distance, cap height)?
  4. When to flag "ask the design team" instead of auto-fixing?

## P2: Contrast fails come from the client master
- **Symptom:** white tagline on a flat salmon background (#F7A289) = **2.0:1** (floor 3:1). Pill text is 3.4:1 (EN) and 3.35:1 (AR) against 4.5:1. All 200 Rio tiles fail Contrast. The sample run has Contrast ×25 fails.
- **Tried:** the audit now measures real pixels (text colour from the layer, background from the rendered tile). An auto-scrim exists for template mode (soft dark gradient).
- **Constraints:** non-destructive; the brand colour must not change without approval; the floors stay 4.5/3.
- **Open:**
  1. How far may an auto-scrim, outline or shadow go on client art (opacity cap, brand-safe colours)?
  2. Should the auto-fix ever run on a master that already fails, or only report "master fails" to the AM?
  3. Is WCAG 2 the right model for LED at distance, or APCA or something else?

## P3: Typography: offer widows ×26 (×33 in an earlier run)
- **Evidence (sample run):** a widow is a last line with a single word; some lines end on "up". Tiles: 1st Ring Road, Al Nassar Tower Vertical, Al Salam Mall, Aqarat, Boulevard Bridge, Hawally Gate, Kuwait Gate, Marina Palms, WareHouse 576×1728 and others.
- **Tried:** greedy line breaking, a minimum font size, ribbon offer caps.
- **Open:**
  1. Knuth–Plass / balanced breaking for EN and AR, with min/max lines and fit-to-box.
  2. A non-breaking list (prepositions, "up to", numbers + units, currency + price).

## P4: Spacing: logo→headline under 6U, ×20
- **Evidence:** Al Hamra Mall Indoor 3.6U, Boulevard Wall 3.2U, Diamond 3.2U, 360 Al Wadi 3.4U (rule: max(6U, logo h)). Offer→hero is 1.3U against 2U.
- **Open:** a constraint solver (Cassowary/kiwi.js) versus our heuristic templates; what priority when space is short (shrink the logo, shrink the headline, or drop the offer)?

## P5: Safe margins ×16, logo clear space ×12, legibility ×11
- **Evidence:**
  - Aqarat logo 4.9u < 6.6u; Crescent Sync 5.6u; WareHouse 5.3u; Thuraya_Full secondary 5.4u.
  - Logo clear space 34–47% of logo height (Al Salam Mall, Avenues Gate Right, Boulevard Bridge, Hawally).
  - Marina_Palms_Full headline cap 33 px < 48 px (ASSUMED).
- **Open:** one consistent order of trade-offs for small or extreme screens.

## P6: Format playbook: EN ribbon offer cap ×16
- **Evidence:** Boulevard Bridge headline cap 31% of height (target 40–55%); Hawally and Kuwait Gate 37%; Mubarak Al Kabeer Gate CTA outside the library zone.
- **Open:** a ribbon (≥ 8:1) layout grammar, meaning how many elements and in what reading order for EN and AR.

## P7: Extreme aspect ratios (xw ≥ ~8:1, xv ≤ ~1:3)
- **Evidence:** ribbons such as Hawally Gate 5832×432 and Kuwait Gate 4460×378 with tiny pills; towers such as 1st Ring Road and Al Nassar. See `shots/v08-ribbon.png`, `v08_1st_Ring_Road.png`, `client-rio/real-*.jpg`.
- **Open:** composition patterns (repeat, sequence, product scale caps, background extension) that work with non-destructive layers.

## P8: Multi-face and combined screens, and seams
- Thuraya: 2 separate screens (2624×608 + 960×540).
- Piccadilly sync: 6080 wide, made by a 1 px crop (2027+2027+2026, never scaled).
- The Palms: 4 panels. Mourouj walls: v-dup of 1680×480 faces. Alshaheed shape groups are ASSUMED.
- **Tried:**
  - hero on the largest face, brand/CTA on the others;
  - when faces are equal and the art has no logo or CTA, repeat the hero on every face (Mourouj_Wall_C, ×4);
  - dashed face outlines.
- **Open:**
  1. Handling seams and bezels (no text across a seam).
  2. Synced motion across faces.
  3. When to repeat versus span.

## P9: Reliable automatic role labelling from PSD layers
- **Evidence (Rio):** generic names ("Vector Smart Object copy", "Group 4", "Layer 6"). The first pass labelled the root group as background, the pills as product and the pack as headline. Fixed with group, visibility, occlusion, multiply-shadow and raster-strip heuristics plus an alignment check.
- **Open:**
  1. A local vision model or classifier for roles (logo, pack, pill, tagline).
  2. Confidence scoring, and the threshold for auto-apply (0.8) versus asking the user in Load & tag.

## P10: Master selection: ratio plus language masters
- **Done:** log-ratio distance, family, coverage, override; language from the filename suffix; EN feeds EN and AR feeds AR.
- **Open:**
  1. Should a tall master win over a wide one when the copy is raster?
  2. Mixed sets, e.g. EN has 3 masters and AR has 1.
  3. The packs differ between languages (EN "Mexico" vs AR "Maize"); detect this and warn?

## P11: Arabic
- **Evidence:** in the sample run the AR headline is smaller than EN (103 vs 118 px on 2.6 Screen), against a target of 110–115% of EN.
- **Rules:** kashida only on single-line wide headlines, max 3 per word; no tracking; leading 1.3–1.6; mirrored order.
- **Open:**
  1. Shaping and kashida in canvas or Electron (HarfBuzz, harfbuzzjs?).
  2. Mixed digits and Latin brand names inside RTL.
  3. Mirroring exceptions (product photo, logo, arrows).
  4. Re-flowing raster Arabic (P1) safely.

## P12: PSD effects are approximations
- **Rendered:** colour overlay, drop shadow, outer glow, stroke (blur = size/2; spread, contour and noise ignored).
- **Not rendered:** inner shadow, bevel, gradient overlay, pattern, blend-if, adjustment layers, smart filters, clipping masks with effects.
- **Open:** use the PSD's own composite or smart-object previews, run Photoshop headless or a UXP script, or reimplement?

## P13: Is the audit valid?
- **Evidence:**
  - Sample run: average 98 but only 51% pass every criterion.
  - Rio run: average 96.2 while every tile fails Contrast because of the master.
  - Campaign-wide checks (for example logo size CV 35%) penalise every tile.
- **Open:**
  1. Calibrate the score against designer judgement (labelled set, weights, hard fails versus soft).
  2. Separate "master defect" from "adaptation defect".
  3. Report campaign checks once instead of per tile.

## P14: UX: two-step Load & tag → Adapt flow
- **Mockup:** `shots/client-rio/mock-tag-*.jpg` (drop zone, master cards, language chip, auto-pairs, layer role chips, `.clear`/`.overlap`, pre-flight blockers/warnings, Continue gated).
- **Open:**
  1. Needs-attention queue design (sort by severity, batch accept).
  2. Edit scope: this tile, this class, or all tiles.
  3. How to show AI confidence and accept/revert badges without clutter.

## P15: Layout library has gaps
- 24 presets have no library section (from the layout validation report), so they fall back to class templates.
- **Open:** generate sections from class rules plus designer review, or learn them from past delivered files.

## P16: Render and export pipeline
- **Plan:** headless Chromium for stills; EffectCraft/EncodeCraft (After Effects + Media Encoder) for MP4 and editable templates.
- **Open:**
  1. Keep pixel-exact parity between the canvas preview and AE output.
  2. Fonts, colour management (sRGB vs LED), frame rates and codecs per screen.
  3. Automated QA on the encoded files.

## P17: Local AI vs cloud providers
- **Candidates:** a local model, Claude, Grok, GPT, Jev AI. Roles: layout parameters (`ai/layout-params.schema.json`), critique against `ai/rubric.json`, role labelling, optional background fill.
- **Open:**
  1. Which provider for which task; confidence thresholds; caching.
  2. Privacy: send only geometry and roles, not client pixels?
  3. Cost per campaign.
  4. Evaluation harness.

## P18: Security and licensing
- Client art stays local. The public prototype (https://dooh-versioner-proto.vercel.app) carries only code and sample art.
- **Open:**
  1. Electron packaging and offline mode.
  2. Font licences (embedding brand fonts).
  3. Licences of libraries and models (ag-psd MIT, psd-tools MIT, …).
  4. Access control if the link is shared; whether to keep the prototype public.
