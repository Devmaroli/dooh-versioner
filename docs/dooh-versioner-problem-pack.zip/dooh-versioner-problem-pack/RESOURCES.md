# Resources: repos, skills and tools that could help the build

- **Verified** 2026-10-29 15:25 Asia/Riyadh (UTC+3) through the GitHub API (redirects followed, 404s dropped).
- **★** = GitHub stars on that date. **Updated** = last push.
- **Licence fit** (we're local, commercial, closed source; our Craft tools are MIT/Apache):
  - ✅ permissive (MIT, Apache, BSD, ISC);
  - ⚠️ copyleft, custom, or needs a commercial licence (check before shipping);
  - 🔬 research code, no licence or not for production.
- "P#" refers to PROBLEMS.md.
- "Kapildev's 'rcp repo'" means **reverse-engineering repos**; see §11.

## 1. Agent and coding skill packs, CLAUDE.md / Cursor rules
| Repo | ★ | Licence | Updated | Why it helps | P# |
|---|---|---|---|---|---|
| https://github.com/multica-ai/andrej-karpathy-skills (was forrestchang/…, redirects) | 226k | ✅ MIT (stated in README) | 2026-04 | The "Karpathy skills": a CLAUDE.md / Cursor rule (think first, simplicity, surgical changes, goal-driven loops). Drop it into our repo for every coding agent. | all |
| https://github.com/anthropics/skills | 185k | ⚠️ mixed (examples Apache-2.0; doc skills source-available) | 2026-10 | Official SKILL.md format plus skill-creator, canvas-design, webapp-testing (Playwright) and pdf. Template for our dooh-* skills. | P13, P14, P16 |
| https://github.com/obra/superpowers | 308k | ✅ MIT | 2026-10 | Agent workflow skills (TDD, plans, debugging, code review). Good discipline for engine work. | all |
| https://github.com/github/spec-kit | 144k | ✅ MIT | 2026-10 | Spec-driven development; fits our SPEC.md, then tests, then code loop. | all |
| https://github.com/VoltAgent/awesome-agent-skills | 37k | ✅ MIT | 2026-10 | Curated 1000+ official skills (Figma, Remotion, GSAP, Hugging Face…). | P16, P17 |
| https://github.com/ComposioHQ/awesome-claude-skills | 78k | ⚠️ no licence file | 2026-09 | Large skills list. | — |
| https://github.com/alirezarezvani/claude-skills | 29k | ✅ MIT | 2026-10 | 380+ skills, including a karpathy-coder reviewer and Playwright. | all |
| https://github.com/hesreallyhim/awesome-claude-code | 57k | ⚠️ unclear | 2026-10 | Commands, hooks and workflows list. | — |
| https://github.com/PatrickJS/awesome-cursorrules | 41k | ✅ CC0 | 2026-05 | Cursor rule examples (TS, React, testing). | — |
| https://github.com/anthropics/claude-cookbooks | 54k | ✅ MIT | 2026-10 | Vision, tool-use and structured-output recipes for our layout-params calls. | P9, P17 |
| https://github.com/modelcontextprotocol/servers | 92k | ✅ MIT → Apache-2.0 | 2026-10 | Reference MCP servers; a pattern for exposing the engine to agents. | P17 |
| https://github.com/mikechambers/adb-mcp | 733 | ✅ MIT | 2026-07 | MCP bridge that lets an AI drive **Photoshop and Premiere** (by an Adobe dev): role labelling and fixes inside real PSDs. | P9, P12, P16 |
| https://github.com/Joeldkelly/banner-forge | 0 | ✅ Apache-2.0 | 2026-04 | A Claude Code skill: one config to all IAB sizes plus QA. Small, but a close analogue to study. | P13, P16 |

## 2. PSD / AI / PDF / font parsing
| Repo | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| https://github.com/Agamnentzar/ag-psd | 735 | ✅ MIT | 2026-10 | Our browser PSD reader and writer. Could write editable PSD output. | P9, P12 |
| https://github.com/psd-tools/psd-tools | 1.5k | ✅ MIT | 2026-10 | Python PSD/PSB: composite, smart objects, effects info. Our reference renderer. | P9, P12 |
| https://github.com/webtoon/psd | 1.4k | ✅ MIT | 2024-02 | Fast TS/WASM PSD parser (Naver Webtoon); handles big PSBs. | P12 |
| https://github.com/mozilla/pdf.js | 54k | ✅ Apache-2.0 | 2026-10 | Render AI (PDF-compatible) and PDF masters in the browser; get text items. | P1, P9 |
| https://github.com/Hopding/pdf-lib | 8.7k | ✅ MIT | 2024-07 | Read and modify PDF structure (layers / OCGs). | P9 |
| https://github.com/opentypejs/opentype.js | 5k | ✅ MIT | 2026-08 | Font parsing and glyph paths; measure text for live-text rebuild. | P1, P3 |
| https://github.com/foliojs/fontkit | 1.7k | ✅ MIT | 2026-10 | Font engine with OpenType layout (GSUB/GPOS), including Arabic. | P1, P11 |

## 3. Canvas editors and templating
| Repo | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| https://github.com/konvajs/konva | 15k | ✅ MIT | 2026-10 | Canvas scene graph with layers, transformers and serialization. Fits an editable Adapt step. | P14 |
| https://github.com/fabricjs/fabric.js | 32k | ✅ MIT | 2026-10 | Object canvas, SVG import/export, text editing. | P14 |
| https://github.com/polotno-project/polotno-studio-app | 5 | ⚠️ needs a Polotno SDK licence key | 2026-10 | Desktop editor with an MCP server for agents; a UX reference. | P14, P17 |
| https://github.com/penpot/penpot | 62k | ⚠️ MPL-2.0 | 2026-10 | OSS design tool with flex/grid layout; a reference for constraints. | P4, P14 |
| https://github.com/tldraw/tldraw | 51k | ⚠️ custom (commercial licence needed) | 2026-10 | Infinite canvas SDK; UX ideas only. | P14 |
| https://github.com/excalidraw/excalidraw | 135k | ✅ MIT | 2026-10 | Simple canvas editor patterns. | P14 |
| https://github.com/GrapesJS/grapesjs | 26k | ✅ BSD-3 | 2026-10 | Template builder with a block/trait model; an idea for the layout library editor. | P15 |

## 4. Layout and constraint solvers
| Repo | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| https://github.com/lume/kiwi | 214 | ✅ BSD-3 | 2025-06 | Cassowary (kiwi) in TS. Solve spacing U, margins and clear zones as weighted constraints instead of hand heuristics. The original IjzerenHein/kiwi.js is archived. | P4, P5, P6, P7 |
| https://github.com/facebook/yoga (now react/yoga) | 19k | ✅ MIT | 2026-10 | Flexbox engine (WASM); stack, row and wrap layouts for pills and ribbons. | P6, P7 |
| https://github.com/vercel/satori | 14k | ⚠️ MPL-2.0 | 2026-10 | HTML/CSS to SVG with real text layout; fast stills without a browser. | P16 |
| https://github.com/chearon/dropflow | 1.4k | ✅ MIT | 2026-10 | CSS layout engine in JS with HarfBuzz shaping; text layout outside the DOM. | P1, P3, P11 |
| https://github.com/bramstein/typeset | 1k | ✅ BSD-2 | 2026-06 | Knuth–Plass line breaking in JS: removes widows and balances lines. | P3 |

## 5. Arabic / RTL shaping and kashida
| Repo | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| https://github.com/harfbuzz/harfbuzzjs | 294 | ✅ MIT | 2026-10 | HarfBuzz WASM: correct Arabic shaping, glyph widths and kashida (tatweel) insertion points. | P11, P1 |
| https://github.com/lojjic/bidi-js | 54 | ✅ MIT | 2026-09 | Unicode bidi algorithm: mixed AR, Latin and digits ordering. | P11 |
| https://github.com/linebender/parley | 771 | ✅ Apache-2.0 | 2026-10 | Rust rich-text layout (bidi, shaping); an option for the Electron or native side. | P11 |
| https://github.com/aliftype/amiri | 478 | ✅ OFL-1.1 | 2026-10 | Arabic font with good kashida (justification) support; a test font. | P11 |
| https://github.com/fribidi/fribidi | 449 | ⚠️ LGPL-2.1 | 2026-10 | Reference bidi (C). | P11 |
| harfbuzz/rustybuzz | 666 | ✅ MIT, **archived** | 2026-07 | Was a Rust HarfBuzz port; archived, don't adopt. | — |

No maintained OSS "kashida algorithm" repo found. ASSUMED approach: HarfBuzz plus rules from the Amiri/W3C "Arabic Layout Requirements" (alreq), max 3 per word.

## 6. Saliency, smart crop and segmentation
| Repo | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| https://github.com/jwagner/smartcrop.js | 13k | ✅ MIT | 2024-03 | Content-aware crop in JS; focal point for photo backgrounds. | P7 |
| https://github.com/danielgatis/rembg | 25k | ✅ MIT (models vary) | 2026-10 | Local background removal; cut out a flattened product. | P9, P7 |
| https://github.com/facebookresearch/sam2 | 20k | ✅ Apache-2.0 | 2026-05 | Segment Anything 2: masks for product and text in flat masters. | P1, P9 |
| https://github.com/xuebinqin/U-2-Net | 9.9k | ✅ Apache-2.0 | 2024-06 | Salient-object model (light). | P7 |
| https://github.com/google-ai-edge/mediapipe | 37k | ✅ Apache-2.0 | 2026-10 | On-device segmentation and face detection (no text over faces). | P7 |
| https://github.com/huggingface/transformers.js | 16k | ✅ Apache-2.0 | 2026-10 | Run ONNX vision models (segmentation, OCR, VLM-lite) in the browser or Electron. | P9, P17 |
| https://github.com/imgly/background-removal-js | 7.4k | ⚠️ AGPL-3.0 | 2025-07 | In-browser background removal; AGPL, so avoid in a closed product. | — |

## 7. Text recognition (rebuilding live text from raster copy)
| Repo | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| https://github.com/PaddlePaddle/PaddleOCR | 92k | ✅ Apache-2.0 | 2026-09 | Best OSS OCR, including Arabic; text boxes for P1 re-flow and rebuild. | P1, P9 |
| https://github.com/naptha/tesseract.js | 39k | ✅ Apache-2.0 | 2026-05 | OCR in the browser (ara+eng). | P1 |
| https://github.com/JaidedAI/EasyOCR | 30k | ✅ Apache-2.0 | 2025-12 | Simple Python OCR with Arabic. | P1 |
| https://github.com/microsoft/OmniParser | 26k | ⚠️ CC-BY-4.0 (models vary) | 2026-07 | UI/element parsing; an idea for role detection. | P9 |

## 8. Design quality, aesthetics, layout generation (research) and contrast
| Repo | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| https://github.com/jaepoong/PosterLlama | 52 | 🔬 no licence | 2024-11 | ECCV'24: layout as HTML from image + constraints. Same idea as our Mode B layout-params. | P7, P13, P17 |
| https://github.com/CyberAgentAILab/layout-dm | 297 | 🔬 Apache-2.0, archived | 2023-10 | LayoutDM diffusion with constraints and metrics (alignment, overlap); reuse the metrics. | P13 |
| https://github.com/CyberAgentAILab/OpenCOLE | 89 | 🔬 Apache-2.0, archived | 2025-03 | Open graphic-design generation pipeline (CyberAgent ads lab). | P13 |
| https://github.com/microsoft/LayoutGeneration | 212 | 🔬 MIT, archived | 2025-01 | LayoutFormer++, LayoutPrompter; evaluation code. | P13 |
| https://github.com/HuiZhang0812/CreatiLayout | 136 | 🔬 no licence | 2025-08 | Layout-to-image (SD3/FLUX). Only relevant for opt-in background fill. | P2 |
| https://github.com/TakaoNarikawa/LayoutGAN-Reimplementation | 19 | 🔬 MIT | 2021-09 | LayoutGAN in PyTorch; background reading. | — |
| https://github.com/Myndex/apca-w3 | 215 | ⚠️ custom "W3 licence, compliant code only" | 2026-05 | APCA perceptual contrast; a better model than WCAG2 for large LED text. Check the licence. | P2, P13 |
| https://github.com/color-js/color.js | 2.3k | ✅ MIT | 2026-10 | Colour spaces plus WCAG21 **and** APCA contrast functions. | P2 |

## 9. Video rendering and export
| Repo | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| https://github.com/remotion-dev/remotion | 69k | ⚠️ Remotion licence (companies above a size need a paid licence) | 2026-10 | React to MP4; a motion option outside AE. | P16 |
| https://github.com/ffmpegwasm/ffmpeg.wasm | 18k | ✅ MIT (ffmpeg core LGPL/GPL by build) | 2026-09 | Encode or check MP4 in the browser or Electron. | P16 |
| https://github.com/mltframework/mlt | 1.9k | ⚠️ LGPL-2.1 | 2026-10 | Multimedia framework (Kdenlive/Shotcut) for templated video. | P16 |
| https://github.com/Zulko/moviepy | 15k | ✅ MIT | 2026-08 | Python video compositing for simple motion sets. | P16 |
| https://github.com/microsoft/playwright | 99k | ✅ Apache-2.0 | 2026-10 | Headless Chromium stills plus visual-regression tests (what we already do). | P16, P13 |
| https://github.com/lovell/sharp | 33k | ✅ Apache-2.0 | 2026-10 | Fast resize, encode and ICC handling for stills export. | P16 |
| https://github.com/electron/electron | 124k | ✅ MIT | 2026-10 | The planned local desktop shell (client art stays local). | P18 |

## 10. Local LLM / VLM runtimes and models
| Repo / model | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| https://github.com/ollama/ollama | 185k | ✅ MIT | 2026-10 | Easiest local model server; private role labelling and critique. | P17, P9 |
| https://github.com/ggml-org/llama.cpp | 133k | ✅ MIT | 2026-10 | Local inference engine (GGUF, vision models). | P17 |
| https://github.com/QwenLM/Qwen3-VL (Qwen2.5-VL redirects here) | 20k | ✅ Apache-2.0 (check per model size) | 2026-01 | Strong local VLM with grounding (boxes); label layers and critique tiles. | P9, P13, P17 |
| https://huggingface.co/microsoft/Florence-2-large (HF, 200 OK) | — | ✅ MIT | — | Small VLM: OCR with regions, detection; fast local role and text boxes. | P1, P9 |

## 11. Reverse engineering ("rcp repo" = RE resources): file formats and interop
**Legality.** Studying formats for **interoperability** (reading and writing our own and clients' files) is generally allowed.
- Use public specs, open parsers, and observation of files we're licensed to open.
- **Don't** crack, bypass DRM or licence checks, or decompile Adobe, Bannerflow or other proprietary apps against their EULA.
- Study Bannerflow only through public docs and its public behaviour.

| Resource | ★ | Licence | Updated | Why | P# |
|---|---|---|---|---|---|
| Adobe Photoshop File Format Spec: https://www.adobe.com/devnet-apps/photoshop/fileformatashtml/ (200 OK) | — | public doc | — | The official PSD/PSB spec: layer records, effects (lfx2), smart objects (SoLd/PlLd), text (TySh). | P9, P12 |
| ag-psd internals: https://github.com/Agamnentzar/ag-psd (`src/additionalInfo.ts`, `effectsHelpers.ts`) | 735 | ✅ MIT | 2026-10 | Readable map of every PSD block we hit (effects, placed layers, text engine data). | P12 |
| psd-tools internals: https://github.com/psd-tools/psd-tools (`psd_tools/composite/effects.py`) | 1.5k | ✅ MIT | 2026-10 | Reference implementation of layer-effect compositing; port it for P12. | P12 |
| https://github.com/layervault/psd.rb | 3.1k | ✅ MIT | 2021-01 | Older Ruby parser with clear docs on the text engine data. | P1 |
| https://github.com/forticheprod/py-aep | 81 | ✅ MIT | 2026-10 | **Reads and writes .aep (RIFX)**: comps, layers, text, Essential Graphics, render queue, layered AI bounds. Huge for EffectCraft export and Screen Adapter tags. | P16, P9 |
| https://github.com/boltframe/aftereffects-aep-parser | 131 | ✅ MIT | 2022-02 | Go AEP parser (static analysis without AE). | P16 |
| https://github.com/inlife/aftereffects-project-research | 80 | ⚠️ no licence | 2023-03 | Notes on the AEP binary structure (research only). | P16 |
| https://github.com/Jam3/ae-to-json (now Experience-Monks) | 246 | ✅ MIT | 2016-05 | AE to JSON via ExtendScript (old, but shows the property walk). | P16 |
| https://github.com/airbnb/lottie-web | 32k | ✅ MIT | 2025-09 | Lottie player; the Lottie JSON schema is a documented AE subset for motion previews. | P16 |
| https://github.com/bodymovin/bodymovin-extension | 342 | ✅ MIT | 2024-08 | AE to Lottie exporter source; shows how AE properties map to JSON. | P16 |
| https://github.com/LottieFiles/dotlottie-web | 932 | ✅ MIT | 2026-10 | Modern Lottie / dotLottie runtime (WASM). | P16 |
| https://github.com/docsforadobe/after-effects-scripting-guide | 184 | ⚠️ community docs | 2026-09 | ExtendScript reference; the sanctioned way to drive AE. | P16 |
| https://github.com/docsforadobe/after-effects-plugin-guide | 53 | ⚠️ community docs | 2026-10 | AE SDK docs. | P12, P16 |
| https://github.com/AdobeDocs/uxp-photoshop | 147 | ✅ Apache-2.0 | 2026-10 | Photoshop UXP API (batchPlay): a sanctioned PSD automation route. | P12, P9 |
| https://github.com/Adobe-CEP/CEP-Resources | 1.8k | ⚠️ Adobe | 2026-02 | CEP panels and samples (AE/AME panels). | P16 |
| AI files: pdf.js / pdf-lib (above) + py-aep `read_ai_layer_bounds` | — | ✅ | — | Modern .ai is PDF-compatible: read the PDF layer (OCG) structure. AIPrivateData (PGF) is undocumented; ASSUMED out of scope, use the PDF side. | P9 |
| Media Encoder presets (.epr) | — | — | — | ASSUMED XML; no OSS parser found. Read them as XML and treat as opaque templates passed to AME/EncodeCraft. | P16 |
| https://github.com/kaitai-io/kaitai_struct | 4.7k | ⚠️ compiler GPL-3; runtimes MIT/Apache | 2026-10 | Declarative binary format language that generates TS/Python parsers. Write a `.ksy` for RIFX/AEP or PSD blocks. | P12, P16 |
| https://github.com/kaitai-io/kaitai_struct_formats (gallery: https://formats.kaitai.io/) | 795 | ⚠️ per-file licence | 2026-10 | Ready specs (PSD-like, RIFF, PDF parts, fonts…). | P12 |
| https://github.com/WerWolv/ImHex | 56k | ⚠️ GPL-2.0 (a tool; fine to use) | 2026-10 | Hex editor with pattern language for exploring PSD and AEP blocks. | P12, P16 |
| https://github.com/WerWolv/ImHex-Patterns | 1k | ⚠️ GPL-2.0 | 2026-09 | Pattern library (many formats). | — |
| 010 Editor templates: https://www.sweetscape.com/010editor/repository/templates/ (200 OK) | — | per template | — | Binary templates (PSD, RIFF, TTF…). 010 Editor itself is commercial. | P12 |
| https://github.com/HexFiend/HexFiend | 5.9k | ✅ BSD-2 | 2025-06 | macOS hex editor with templates. | — |
| https://github.com/wtsxDev/reverse-engineering | 11k | ⚠️ no licence | 2023-07 | Awesome reverse-engineering list (tools, books). | — |
| https://github.com/ReversingID/Awesome-Reversing | 752 | ✅ CC0 | 2026-05 | Curated reverse-engineering resources. | — |
| https://github.com/alphaSeclab/awesome-reverse-engineering | 5.2k | ⚠️ no licence | 2021-09 | Large reverse-engineering index (old). | — |

## 12. Bannerflow-like / ad template engines (open source)
No mature OSS equivalent of Bannerflow or Celtra exists.
| Repo | ★ | Licence | Updated | Why |
|---|---|---|---|---|
| https://github.com/Joeldkelly/banner-forge | 0 | ✅ Apache-2.0 | 2026-04 | Config to all sizes, QA and zips (IAB, an agent skill). |
| https://github.com/lovecomm/h5banner | 3 | ⚠️ no licence | 2026-09 | Resize-one-banner CLI (HTML5/GSAP). |
| https://github.com/polotno-project/polotno-studio-app | 5 | ⚠️ SDK key | 2026-10 | Template editor plus MCP. |

Dropped, not found (404): polotno-studio, heyimjames/tela, naver-ai/LayoutDM, LayoutGAN official, PosterLlama alternate paths, microsoft/Florence-2 (GitHub), SweetScape templates on GitHub, jlfwong/bidi-js, tfjs smartcrop, wilsonzlin/aep, ai2svg forks, any .epr parser.
"rcp" exact match: 1ay1/rcp (Retrieval Context Protocol, 1★) is not relevant.
